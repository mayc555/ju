(() => {
  'use strict';

  const en = Object.freeze({
    "获得奖励！":"Earn rewards!",

"未接入浏览器提示UI":"Browser prompt UI is unavailable","转个沙":"Sand Spin","沙块拼图":"Block Puzzle","解绳子":"Untie the Ropes","实验数据源需要配置 resourceBaseUrl":"The test source requires resourceBaseUrl","副玩法关卡源不在候选列表中":"Side-mode level source is not in the candidate list","副玩法关卡清单不可用":"Side-mode level list is unavailable","副玩法关卡清单格式不正确":"Invalid side-mode level list","副玩法关卡内容不匹配":"Side-mode level content does not match","副玩法关卡号不合法":"Invalid side-mode level number","解锁暂存处":"Unlock Extra Slot","扩展槽位":"Add a Slot","转盘加速":"Speed Up the Wheel","皮肤解锁":"Unlock Skin","看视频得金币":"Watch for Coins","商店免费刷新":"Free Shop Refresh","副玩法跳过关卡":"Skip Side-mode Level","FOREST_INSIGHT_DEBUG_ERROR: Debug 菜单主动抛出报错":"FOREST_INSIGHT_DEBUG_ERROR: deliberate debug error","已安排测试报错，请联网等待上报":"Test error scheduled. Connect to send the report.","此包未配置洞察，请重新打包":"Insight is not configured. Rebuild the package.","ab-e 新机制":"ab-e New Mechanic","转了个沙关卡源已切换":"Sand Spin source switched","添加中":"Adding...","清空中":"Clearing...","已清空":"Cleared","清空失败":"Could not clear","玩法":"Gameplay","吸量关卡包不可用":"Featured level package unavailable","请在关卡管理器的“吸量关卡”页签导入":"Import under Featured Levels in the level manager","测试通关":"Test Win","通关双倍金币":"Double Coins","复活":"Revive","测试时间结束":"Test Timeout","超好玩解锁":"Unlock Mode","副玩法通关双倍金币":"Side-mode Double Coins","鼠":"Rat","牛":"Ox","虎":"Tiger","兔":"Rabbit","龙":"Dragon","蛇":"Snake","马":"Horse","羊":"Goat","猴":"Monkey","鸡":"Rooster","狗":"Dog","猪":"Pig","猜瓶子关卡文档版本不匹配":"Guess the Cans document version mismatch","猜瓶子关卡种子基数不合法":"Invalid Guess the Cans seed base","猜瓶子引导关瓶数不合法":"Invalid tutorial can count","猜瓶子种子覆盖不合法":"Invalid can seed coverage","猜瓶子关卡清单格式不合法":"Invalid Guess the Cans level list","[guess-bottle] 关卡清单刷新失败，沿用已加载版本":"[guess-bottle] Could not refresh level list; using loaded version",

"用于展示排行榜头像和昵称":"Show your leaderboard name and avatar","新版本已经准备好，是否重启应用？":"An update is ready. Restart the game?","吸量玩法关卡":"Featured Levels","加速中":"Speed Boost","会[color=#ffe644]中断连胜[/color]！":" will [color=#ffe644]end your win streak[/color]!","账号状态已更新":"Account updated","返回首页":"Back to Home","没有可选择的盒子":"No tray available","没有可敲的目标":"No target to break","现在不能冻结时间":"Time Freeze is unavailable right now","商店获取奖励":"Shop Reward","设置页重开":"Restart from Settings","顶部关卡标题：":"Level title: ","开":"On","关":"Off","本次运行生效，重启恢复默认":"Applies until the game restarts","自动玩：":"Autoplay: ","切换沙子音效：":"Sand sound: ","断续":"Pulsed","连续":"Continuous","正在验证新源":"Checking new source","分组已切换":"Group switched","切换失败，保留原源":"Could not switch. Keeping current source.","数据源已切换":"Source switched","免广告：":"Ad-free: ","恢复中":"Restoring...","已恢复":"Restored","恢复失败":"Could not restore","永远当做新人：":"Always treat as new player: ","已邀请一人":"One player invited","添加失败":"Could not add","已获得 1000 金币":"You got 1,000 coins!","云存档未就绪":"Cloud save is not ready","加载玩法中":"Loading mode...","加载失败，请重试":"Could not load. Try again.","切换数据源":"Switch source","网络不稳定，金币稍后自动补发":"Connection unstable. Your coins will arrive automatically.","云存档暂不可用，本关金币未发放":"Cloud save unavailable. Coins have not been awarded yet.","副玩法失败页重开":"Restart side mode","失败页重开":"Restart level","当前进度将不会保存":"Your current progress will not be saved","设置页返回首页":"Return Home from Settings","主播推荐":"Creator Picks","超好玩通关回主页":"Return Home after completing mode","现在不能加时":"Cannot add time right now","已经显示所有数字，只要把数字从小到大连接就行了！":"All numbers are visible. Connect them in order!","现在不能剪绳子":"Cannot cut the rope right now","现在不能使用无限时间":"Unlimited Time is unavailable right now","现在不能提示":"No hint available right now","没有可透视的瓶子":"No hidden can to reveal","请输入口令":"Enter access code","口令":"Access code","基础接沙":"Catch the Sand","拖动红色沙槽到沙池下方接沙。":"Drag the red tray under the sand pool.","多色接沙":"Match the Colors","两种颜色各接对应颜色的沙。":"Fill each tray with its matching sand color.","拖动 L 形沙槽，观察碰撞和接沙。":"Drag the L-shaped tray around the obstacles.","先填满普通沙槽，冰冻层数减少后再接沙。":"Fill regular trays to remove the ice layers.","单向槽（横向）":"Slide Sideways","带箭头的沙槽只能横移到沙池下方。":"Arrow trays can only move sideways.","单向槽（纵向）":"Slide Up and Down","带箭头的沙槽只能上下移动。":"Arrow trays can only move up or down.","填满上层后继续填下层，观察联动拖动。":"Fill the top layer, then the next. Linked trays move together.","先填满带钥匙的沙槽，观察自动解锁。":"Fill the key tray to unlock the other trays.","沙管道（直管）":"Straight Pipes","拖动沙槽接沙，观察管道持续补入沙池。":"Fill trays while the pipe refills the sand pool.","沙管道（弯管）":"Bent Pipes","接沙后观察沙粒经过弯道的流动。":"Watch the sand flow around the pipe bends.","先用左侧沙池填满沙槽，解除右侧玻璃。":"Fill the tray from the left pool to remove the glass.","锤子与墙（墙体）":"Walls","拖动沙槽绕过中间的墙。":"Move the trays around the wall.","锤子与墙（飞锤）":"Flying Hammer","填满带锤沙槽，观察飞锤击碎右侧岩石。":"Fill the hammer tray to break the rocks.","拖动任一沙槽，观察整组一起移动。":"Drag one linked tray to move the whole group.","依次填满门上方的三个沙槽，观察大卷帘门倒数、收起和破碎效果。":"Fill the three trays above the gate to open it.","每填满一个沙槽，观察糖果棒收缩。":"Each full tray shrinks the candy stick.","移开平台上的沙槽，观察平台打开。":"Move the trays off the platform to open it.","先填满普通沙槽，观察桌布解除。":"Fill regular trays to remove the tablecloth.","填满带时钟的沙槽，观察时钟飞行和加时。":"Fill the clock tray to add time.","向上拉出生成器中的沙槽，再取下一个。":"Pull a tray out of the dispenser, then take the next one.","绿色沙槽可穿过绿色地块，红色沙槽需绕行；按住绿色槽观察地块下沉。":"Green trays can cross green tiles. Other colors must go around.","按红→绿→紫→黄逐层接沙，观察下一层外框与剩余层数。":"Fill each layer in order: red, green, purple, then yellow.","红槽接走初始红沙，双泵按蓝→黄补沙；耗尽下沉后，沙槽可穿过原占格。":"Collect the red sand. The pumps refill blue, then yellow.","左侧四个沙槽依次接满，仙人掌每次缩回一格，缩完花盆消失，右槽才能上移接沙。":"Fill the left trays to shrink the cactus and clear a path.","沙袋里的沙全部接走后，沙袋解开消失并释放占格。":"Empty the sand bag to clear its space.","沙袋（管道）":"Piped Sand Bag","管道沙接完后沙袋消失，指向它的管道收回。":"Empty the bag to remove it and retract its pipes.","循环补沙":"Refilling Sand","持续接沙，沙池排空后两秒补回，沙槽容量较大。":"The pool refills two seconds after it empties.","点击底部磁铁，再选一个沙槽，观察隔空吸沙。":"Tap Magnet, then choose a tray to fill.","点击底部锤子，再敲两格沙槽，观察拆分。":"Tap Hammer, then choose a tray to split.","先拖动沙槽启动倒计时，再点击时间冻结。":"Move a tray to start the timer, then tap Time Freeze.","已执行":"Done","材质调参":"Material Settings","1. 冰箱上方藏着一排易拉罐，目标是猜出它们的正确顺序。":"1. A row of cans is hidden above the fridge. Guess their order.","2. 把托盘里的易拉罐拖进冰箱下方格子；拖动或点选两个罐子可以交换位置。":"2. Drag cans into the slots. Drag or tap two cans to swap them.","3. 格子放满后点击托盘验证，会提示有几个位置正确。":"3. Fill every slot, then tap Check to see how many are correct.","4. 验证后进入 15 秒回想时间（点击托盘可跳过），之后易拉罐留在原位，在格子内拖动交换后再次验证。":"4. After each check, review for 15 seconds or tap to skip. Swap cans and try again.","5. 全部位置正确即可过关；时间耗尽或验证次数用完则挑战失败。":"5. Put every can in the right spot to win. Watch the timer and tries remaining.","6. 道具：透视可翻开一个藏起来的罐子，提示可标出一个罐子的正确位置，无限时间可暂停计时。":"6. Reveal uncovers a hidden can. Hint shows a correct spot. Unlimited Time pauses the timer.","验证":"Check","点击转盘验证，看看正确几个":"Tap Check to see how many are correct","太棒了！":"Great Job!","奖励x":"Rewards x","按数字从小到大，把这些格子连起来":"Connect the numbers from lowest to highest","4 周围没有 5，但只剩一个空格子——5 一定藏在里面！连过去试试":"There is only one empty cell left. The missing 5 must be there!","现在按数字顺序把所有格子一笔连完吧！":"Connect every cell in number order with one line!","还有中间数字没有连上，连上所有数字才能过关！":"Some numbers are not connected. Connect them all to win!","最后一步：自己完成":"Your turn: finish the path","观察碎片的缺口、花纹，把瓷器还原。":"Match the edges and patterns to rebuild the pottery.","切换关卡失败，请重试":"Could not switch levels. Try again.","国家/地区":"Country/Region","全球":"Global","资料":"Profile","排行榜暂不可用，请稍后重试。":"Leaderboard unavailable. Please try again.","完成一关即可参与排名。":"Complete a level to join the leaderboard.","复制失败，请重试":"Could not copy. Try again.","魔杖正在施法":"The wand is casting a spell","分享未完成，请重试":"Share not completed. Try again.","分享状态保存失败，请重试":"Could not save share status. Try again.","订阅失败，请稍后重试":"Could not subscribe. Try again later.","保存失败，请稍后重试":"Could not save. Try again later.","被锁住的串不能移动，需要被消除！":"Locked skewers cannot move. Clear them first!","被锁住的串只能放相同水果!":"Only matching fruit can go on a locked skewer!","试试挪动一颗暂存处的糖葫芦呢！":"Try moving a fruit from the extra slot!","试试挪动一颗糖葫芦放在这里呢！":"Try moving a fruit here!","试试解锁一颗糖葫芦暂存处呢！":"Try unlocking an extra slot!","被锁住的糖葫芦不能移动,需要被消除":"Locked skewers cannot move. Clear them first.","被糖纸封住的串串需要合成目标串串将其撕开(目标是万能果的话,合成任意串串即可)":"Merge the target skewer to remove the wrapper. A wild target accepts any merge.","当前没有问号遮罩":"No hidden fruit to reveal","糖葫芦移动中，请稍后再试":"Fruit is moving. Try again in a moment.",

    '点击使用时间冻结': 'Tap to use Time Freeze', '点击使用磁铁': 'Tap to use Magnet', '点击使用锤子': 'Tap to use Hammer',
    '点击沙槽将它填满': 'Tap a tray to fill it', '点击沙槽将它分裂': 'Tap a tray to split it',

    '卡住啦！': 'Stuck!', '沙子满啦！': 'Tray Full!', '生命用完！': 'Out of Lives!', '次数用完！': 'No Tries Left!',
    '失去[color=#ffe644]连胜[/color]将大幅减少奖励!': 'Keep your [color=#ffe644]win streak[/color]!',
    '失去连胜将大幅减少奖励!': 'Keep your win streak!',

"墨镜爱心":"Cool Hearts",
"彩虹沙浪":"Rainbow Waves",
"黑猫仰望":"Stargazing Cat",
"鲜红草莓":"Sweet Strawberry",
"彩色回廊":"Color Maze",
"彩锦流光":"Koi Glow",
"星旋彩梦":"Star Spiral",
"七巧风车":"Pinwheel Party",
"柯基听风":"Breezy Corgi",
"镜里花期":"Blooming Mirror",
"橘梦小猴":"Cheeky Monkey",
"杯中兔梦":"Teacup Bunny",
"彩虹孵梦":"Rainbow Dreams",
"风味漫游":"Snack Time",
"逐梦绿茵":"Soccer Dreams",
"灯月流金":"Moonlit Lanterns",
"星帽奇兔":"Magic Bunny",
"锦鲤逐浪":"Koi Splash",
"椰风浅湾":"Palm Bay",
"秋灯小筑":"Cozy Lanterns",
"风吻麦田":"Golden Fields",
"游鱼星河":"Starry Fish",
"晴树浮岛":"Floating Island",
"彩虹啵啵":"Rainbow Pop",
"元气大E":"Big E Energy",
"彩虹漩涡":"Rainbow Swirl",
"九宫魔方":"Magic Squares",
"心动企鹅":"Happy Penguin",
"发呆小鸡":"Daydream Chick",
"呆萌牛牛":"Silly Cow",
"彩虹蜡笔":"Rainbow Crayons",
"草莓猫咪":"Strawberry Kitty",

    '再加60秒，继续游戏': 'Add 60s to keep playing!',
    '移出所有砖块，继续游戏': 'Clear all blocks to keep playing',
    '清空棋盘，继续游戏': 'Clear the board to keep playing',
    '恢复1颗心，继续游戏': 'Restore 1 heart to keep playing',
    "加速": "Speed Up",
    "加载未完成，点击重试": "Not loaded. Tap to retry.",
    "请点击想要透视的?号瓶子": "Tap a ? bottle to reveal it",
    "加载失败，请稍后重试": "Could not load. Try again later.",
    "从 1 开始 · 一笔连完 · 不能重复": "Start at 1 · One path · No repeats",
    "新机关：锁": "New Mechanic: Locks",
    "连到带钥匙的格子收集钥匙，集齐 3 把就能解开被锁住的格子": "Connect to key tiles. Collect 3 keys to unlock the locked tiles.",
    "显示数字": "Show Numbers",
    "折扣": "OFF",

    "好的好的": "Got It",
    "规则1": "Rule 1",
    "规则2": "Rule 2",
    "规则3": "Rule 3",
    "规则4": "Rule 4",
    "规则5": "Rule 5",
    "你失去了1个体力": "You lost 1 stamina",
    "先填满内层沙槽，解锁\n下方的沙槽！": "Fill the inner tray to unlock\nthe tray below!",
    "时间到！": "Time’s Up!",
    "再加[color=#ffe644]60[/color]秒，继续游戏\n失去[color=#ffe644]连胜[/color]将大幅减少奖励!": "Add [color=#ffe644]60[/color] seconds to keep playing!\nKeep your [color=#ffe644]win streak[/color]!",
    "观看广告即可解锁副玩法当日体验权限（主玩法通过第20关后，可免广告直接体验）": "Watch an ad to try this mode today.\nClear Level 20 to play without ads.",
    "玩法加载中…": "Loading mode…",
    "每天只能领取[color=#db642d]1[/color]次": "Claim [color=#db642d]once[/color] per day",
    "商店刷新：": "Refresh:",
    "<b>订阅 <font color=\"#CD693B\">抖音推荐</font> 即可获得奖励</b>": "<b>Subscribe to <font color=\"#CD693B\">recommendations</font> for rewards</b>",
    "随机道具 x 1": "Random Booster ×1",
    "道具名": "Booster",
    "道具文案[color=#ffe644]高亮文案[/color]": "Booster details [color=#ffe644]Bonus[/color]",
    "重新开始会[color=#ffe644]中断连胜[/color]！": "Restarting will [color=#ffe644]end your win streak[/color]!",
    "玩家名字七个字": "Player",
    "填满所选坑位！": "Fill the selected tray!",
    "时间冻结": "Time Freeze",
    "无限体力": "Unlimited",
    "锤子": "Hammer",

    "请点击右上角，将游戏添加到我的小程序": "Open the top-right menu and save this game.",
    "加载中...": "Loading…",
    "该奖励已领取": "Reward already claimed",
    "演示暂时无法加载": "Preview unavailable",
    "我（模拟）": "Me (Demo)",
    "加载中…": "Loading…",
    "虚位以待": "Open Spot",
    "ID已复制": "ID copied",
    "一路通关": "Level Runner",
    "星星点灯": "Starlight",
    "快乐沙粒": "Happy Sand",
    "通关不求人": "Solo Solver",
    "已完成": "Completed",
    "订阅成功，请点击领取奖励": "Subscribed! Claim your reward.",
    "当前抖音版本不支持订阅，请升级抖音后重试": "Subscriptions are unavailable in this version.",
    "订阅功能配置异常，请稍后重试": "Subscriptions are unavailable. Try again later.",

    '玩个儿沙子': 'Block Maze',
    '拖动沙槽': 'Drag the Sand Tray',
    '设置': 'Settings', '音乐': 'Music', '音效': 'Sound', '震动': 'Haptics',
    '跳过关卡': 'Skip', '切换关卡': 'Switch Level', '版本号': 'Version',
    '皮肤': 'Skins', '商店': 'Shop', '主页': 'Home', '卡组': 'Deck', '排行': 'Leaderboard', '已满': 'Full',
    '关卡': 'Level', '选择目标': 'Choose a target', '磁铁': 'Magnet', '填满所选坑位': 'Fill the selected pit',
    '获取体力': 'Get Stamina', '获取金币': 'Get Coins', '今日剩余': 'Remaining today',
    '排行榜': 'Leaderboard', '领取': 'Claim', '回到主页': 'Back to Home', '继续游戏': 'Continue',
    '重新开始': 'Restart', '退出': 'Quit', '认输': 'Give Up', '提示': 'Tip', '规则': 'Rules', '玩法说明': 'How to Play',
    '通关失败': 'Level Failed', '时间到': 'Time’s Up', '太棒了': 'Great Job!', '奖励': 'Reward', '通关奖励': 'Level Reward',
    '新玩法': 'New Game Mode', '新玩法已解锁': 'New Game Mode Unlocked', '已解锁': 'Unlocked', '解锁': 'Unlock',
    '看视频领取': 'Watch a Video to Claim', '新玩法': 'New Mode', '每日道具': 'Daily Items',
    '添加桌面奖励': 'Add to Home', '恭喜获得': 'Congratulations! You got', '收藏奖励': 'Favorite Reward',
    '邀请有礼': 'Invite & Earn', '邀请好友进入游戏': 'Invite friends to play', '获得奖励': 'Reward Earned',
    '加载中': 'Loading', '累计分享': 'Total Shares', '人进入游戏': 'friends joined the game', '访问福利': 'Visit Reward',
    '明日再来领取': 'Come back tomorrow to claim', '订阅奖励': 'Subscription Reward', '订阅': 'Subscribe',
    '抖音推荐': 'Recommended on Douyin', '即可获得奖励': 'to receive a reward', '随机道具': 'Random Item',
    '商店刷新': 'Shop Refresh', '趣味关卡': 'Fun Levels', '创意玩法': 'Creative Modes', '超好玩': 'So Much Fun',
    '玩法加载中': 'Loading game mode', '重试': 'Try Again', '新玩法': 'New Mode',
    '分享有礼': 'Share & Earn', '已复制': 'Copied', '复制失败': 'Copy Failed', '请重试': 'Please try again',
    '新玩法': 'New Mode', '你失去了': 'You lost', '个体力': 'stamina', '再加': 'Add', '失去': 'Lost',
    '连胜': 'Win Streak', '将大幅减少奖励': 'Your reward will be greatly reduced', '免费': 'Free',
    '双层槽': 'Double-Layer Pit', '先填满内层沙槽': 'Fill the inner pit first', '下方的沙槽': 'the pit below',
    '每日道具': 'Daily Items', '每天只能领取': 'Can only be claimed once per day', '金币不足': 'Not enough coins',
    '恢复体力': 'Restore Stamina', '看完视频': 'Watch the full video', '才能获取奖励': 'to receive the reward',
    '视频暂时无法播放': 'The video is temporarily unavailable', '体力恢复成功': 'Stamina restored',
    '冰冻槽': 'Frozen Pit', '单向槽': 'One-Way Pit', '双层槽': 'Double-Layer Pit', '钥匙与锁': 'Keys & Locks',
    '沙管道': 'Sand Pipe', '玻璃盖': 'Glass Cover', '锤子与墙': 'Hammer & Wall', '连接槽': 'Linked Pits',
    '卷帘门': 'Roller Door', '糖果棒': 'Candy Cane', '平台盖': 'Platform Cover', '桌布': 'Tablecloth',
    '时钟槽': 'Clock Pit', '生成器': 'Generator', '彩色地块': 'Colored Tiles', '多层沙槽': 'Multi-Layer Pit',
    '沙泵': 'Sand Pump', '仙人掌': 'Cactus', '沙袋': 'Sandbag', '沙块爆破': 'Sand Block Blast',
    '数字连线': 'Number Link', '拼陶瓷': 'Ceramic Puzzle', '猜瓶子': 'Guess the Bottle', '串糖葫芦': 'Candied Hawthorn',
    '更多好玩的玩法正在准备中': 'More fun modes are on the way', '创意玩法制作中': 'Creative modes in development',
    '敬请期待': 'Coming Soon', '玩法加载失败': 'Could not load this mode', '待开发': 'Coming Soon',
    '玩法建议': 'Mode Suggestions', '反馈功能暂未开放': 'Feedback is not available yet', '感谢支持': 'Thanks for your support',
    '免费解锁': 'Unlock for Free', '已看': 'Watched', '进入失败': 'Could not enter', '请再试一次': 'Please try again',
    '重新挑战或中途返回首页': 'Retry or return to the home screen', '倍率回到': 'Multiplier resets to',
    '已获得的卡牌不会减少': 'Cards you have earned will not be lost', '卡牌累计达到目标即可领取对应奖励': 'Collect enough cards to claim each reward',
    '新一期开始后进度重置': 'Progress resets when a new event begins', '请及时领取': 'Claim your rewards in time',
    '累计': 'Total', '小时': 'hours', '剩余时间': 'Time Remaining', '超级宝箱': 'Super Chest', '宝箱': 'Chest',
    '终极大奖': 'Grand Prize', '已领取': 'Claimed', '本期奖励已全部达成': 'All rewards for this event have been earned',
    '连续获胜可提升倍率': 'Keep winning to increase your multiplier', '失败会回到': 'A loss resets it to',
    '每通关一个主线关卡即可获得卡牌': 'Earn cards by clearing main levels', '获得数量等于当前倍率': 'The number earned matches your current multiplier',
    '连续通关倍率逐档提升': 'Your multiplier rises with each consecutive win', '闯关失败': 'Level Failed',
    '账号同步中': 'Syncing account', '请稍后再试': 'Please try again later', '背景': 'Background', '方块': 'Blocks',
    '特效': 'Effects', '使用中': 'Equipped', '使用': 'Use', '解锁失败': 'Unlock Failed', '账号同步中': 'Syncing account',
    '金币不足': 'Not enough coins', '今日次数已用完': 'You’ve used all attempts for today', '明天再来': 'Come back tomorrow',
    '明天见呀': 'See you tomorrow!', '奖励给你留着啦': 'Your reward will be waiting', '今天签过啦': 'Already claimed today',
    '明天再来哦': 'Come back tomorrow', '金币在打包': 'Your coins are being packed', '明天来拿呀': 'Pick them up tomorrow',
    '道具们在等你': 'Your items are waiting', '明天见': 'See you tomorrow', '明天签到更惊喜': 'Tomorrow’s check-in has a surprise',
    '签到': 'Check In', '已领取': 'Claimed', '明日再来': 'Come back tomorrow', '奖励已到账': 'Reward received',
    '今天任务完成': 'Today’s task is complete', '好运连连哦': 'Good luck is on your side', '坚持就是胜利': 'Consistency is the key to winning',
    '主玩法通过第': 'Clear main level ', '关后': ' to unlock', '通关第': 'Clear level ', '关后开启': ' to unlock',
    '开启新一期': 'Start a new event', '每周一': 'Every Monday', '周五': 'Friday', '最高': 'Max',
    '网络不佳': 'Poor connection', '道具未消耗': 'No item was used', '试试使用道具': 'Try using an item',
    '中断连胜': 'End your win streak', '重新开始会': 'Restarting will', '你将失去': 'You will lose',
    '时间冻结不了': 'Time cannot be frozen', '本期奖励已全部达成': 'All rewards for this event have been earned',
    '查看': 'View', '关闭': 'Close', '确认': 'Confirm', '取消': 'Cancel', '返回': 'Back', '开始': 'Start',
    '暂停': 'Paused', '继续': 'Continue', '排行榜': 'Leaderboard', '主线': 'Main Levels', '主页': 'Home',
    '免费领取': 'Claim for Free', '领取奖励': 'Claim Reward', '获得': 'Earned', '金币': 'Coins', '体力': 'Stamina',
    '分钟': 'min', '秒': 'sec', '次': 'times', '等级': 'Level', '通关': 'Clear', '失败': 'Failed',
    '暂无数据': 'No data available', '玩家': 'Player', '我的排名': 'My Rank', '我的': 'Me',
    '原版': 'Original', '浏览器离线存档，不提供抖音登录': 'Browser offline save · Douyin login is unavailable',
    '该平台能力在浏览器离线版不可用': 'This platform feature is unavailable in the offline browser edition',
    '浏览器无插屏广告': 'Interstitial ads are unavailable in the browser',
    '浏览器无激励广告，未发放广告奖励': 'Rewarded ads are unavailable in the browser · No ad reward was granted',
    '浏览器不提供抖音分享': 'Douyin sharing is unavailable in the browser',
    '浏览器适配未启用震动': 'Vibration is disabled in the browser edition',
    '启动遇到问题：': 'Startup problem: ', '正在加载原版游戏…': 'Loading the original game…',
    '模块尚未加载：': 'Module has not loaded: ', '无法加载 ': 'Could not load ',
    '新手教学': 'Tutorial', '点击任意处继续': 'Tap anywhere to continue', '拖动': 'Drag',
    '拖动沙槽接沙': 'Drag a pit beneath the matching sand to collect it',
    '拖动红色沙槽到沙池下方接沙': 'Drag the red pit beneath the sand to collect it',
    '拖动任一沙槽': 'Drag any pit', '拖动沙槽绕过中间的墙': 'Move the pit around the wall in the middle',
    '带箭头的沙槽只能上下移动': 'Pits with arrows can only move up and down',
    '带箭头的沙槽只能横移到沙池下方': 'Pits with arrows can only slide sideways beneath a sand pool',
    '先拖动沙槽启动倒计时': 'Move a pit to start the countdown', '不动槽就不计时': 'Move a tray to start',
    '同色沙进同色槽': 'Match the sand colors', '空位就是法宝哦': 'Keep a space open',
    '卡住就绕空位': 'Go around empty spaces', '挪槽先留落脚地': 'Leave room to move',
    '单向槽只走一边': 'One-way trays move one way', '联动槽整组一起挪': 'Linked trays move together',
    '空位留给关键槽': 'Save room for key trays', '绕一绕就有路啦': 'Find a way around',
    '挪到容器下接沙沙': 'Move trays under the sand', '先填满带钥匙的沙槽': 'Fill the pit with the key first',
    '先填满普通沙槽': 'Fill the regular pits first', '填满上层后继续填下层': 'Fill the upper layer, then continue with the lower one',
    '填满所选坑位': 'Fill the selected pit', '先用左侧沙池填满沙槽': 'Fill the pit using the sand pool on the left',
    '填满带时钟的沙槽': 'Fill the pit with the clock', '填满带锤沙槽': 'Fill the pit with the hammer',
    '按数字从小到大': 'Follow the numbers from smallest to largest', '一笔连完': 'Connect them all in one stroke',
    '不能重复': 'Do not cross the same path twice', '只要把数字从小到大连接就行了': 'Connect the numbers in ascending order',
    '两种颜色各接对应颜色的沙': 'Match each of the two sand colors to its pit', '拖动或点选两个罐子可以交换位置': 'Drag or tap two jars to swap them',
    '拖动易拉罐到冰箱下方格子': 'Drag the can to a space beneath the fridge', '拖动放置': 'Drag to place',
    '把托盘里的易拉罐拖进冰箱下方格子': 'Drag the can from the tray into a space beneath the fridge',
    '把瓶子拖进柜子里': 'Drag the bottle into the cabinet', '拖动碎片拼好盘子': 'Drag the pieces to reassemble the plate',
    '把瓷器还原': 'Restore the ceramic piece', '放到暂存处': 'Move it to the holding area', '清空棋盘': 'Clear the board',
    '格子放满后点击托盘验证': 'Fill the spaces, then tap the tray to check', '全部位置正确即可过关': 'Place everything correctly to clear the level',
    '提示可标出一个罐子的正确位置': 'A hint reveals the correct spot for one jar', '已经显示所有数字': 'All numbers are already shown',
    '没有可撤回的操作': 'There is no move to undo', '本关没有时间限制': 'There is no time limit on this level',
    '时间已用完': 'Time is up', '本局已结束': 'This round has ended', '网络不佳': 'Connection is poor',
    '道具未消耗': 'No item was used', '打开侧边栏失败': 'Could not open the sidebar', '添加到桌面失败': 'Could not add to home screen',
    '分享成功': 'Shared successfully', '分享未完成': 'Sharing was cancelled', '切换关卡失败': 'Could not switch levels',
    '关卡清单刷新失败': 'Could not refresh the level list', '保存失败': 'Save failed', '执行失败': 'Action failed',
    '口令错误': 'Incorrect code', '处理中': 'Processing', '加载失败': 'Loading failed', '异形沙槽': 'Shaped Pit',
    '单向槽': 'One-Way Pit', '双层槽': 'Double-Layer Pit', '多层沙槽': 'Multi-Layer Pit', '连接槽': 'Linked Pits',
    '钥匙与锁': 'Keys & Locks', '冰冻槽': 'Frozen Pit', '时间冻结道具': 'Time Freeze', '无限时间': 'Unlimited Time',
    '剩余时间': 'Time Remaining', '次数用完': 'No attempts remaining', '次数已用完': 'No attempts remaining',
    '点击底部磁铁': 'Tap the magnet at the bottom', '点击底部锤子': 'Tap the hammer at the bottom',
    '点击托盘可跳过': 'Tap the tray to skip', '点击任意处继续': 'Tap anywhere to continue',
    '每日奖励已领取': 'Daily reward claimed', '每日签到': 'Daily Check-In', '签到': 'Check In',
    '排行榜': 'Leaderboard', '我的排名': 'My Rank', '去玩关卡吧': 'Play some levels', '去闯关吧': 'Start a level',
    '先去玩两关': 'Clear two levels first', '明天再来': 'Come back tomorrow', '今日次数已用完': 'No attempts left today',
    '奖励不会跑': 'Your reward will be waiting', '奖励不跑哦': 'Your reward will be waiting', '连签不断': 'Keep your streak going',
    '连续签满七天吧': 'Check in for seven days in a row', '七日大礼在向你招手': 'A seven-day reward is waiting for you',
    '快乐翻倍': 'Double the fun', '大奖就在前面': 'The grand prize is just ahead', '好运不停歇': 'Keep the good luck coming',
    '华容道王者': 'Sliding Puzzle Master', '拼图小能手': 'Puzzle Pro', '消消乐达人': 'Match Master', '沙子大师': 'Sand Master',
    '图案罐': 'Pattern Jar', '午后咖啡': 'Afternoon Coffee', '富有之路': 'Road to Riches', '夜猫子': 'Night Owl',
    '明清彩瓷': 'Ming-Qing Porcelain', '糖葫芦': 'Candied Hawthorn', '沙块爆破': 'Sand Block Blast',
    '串糖葫芦': 'Make a Candied Hawthorn Skewer', '猜瓶子': 'Guess the Bottle', '拼陶瓷': 'Ceramic Puzzle',
    '数字连线': 'Number Link', '沙袋': 'Sandbag', '沙泵': 'Sand Pump', '仙人掌': 'Cactus',
    '猜瓶子关卡加载失败': 'Could not load the Guess the Bottle level', '猜瓶子关卡号不合法': 'Invalid Guess the Bottle level number',
    '现在不能使用': 'Cannot use this right now', '现在不能使用魔杖': 'The wand cannot be used right now',
    '现在按数字顺序把所有格子一笔连完吧': 'Connect every space in numerical order with one continuous line',
    '目标': 'Goal', '看看正确几个': 'See how many are correct', '移出所有砖块': 'Remove all the blocks', '移开平台上的沙槽': 'Move the pit off the platform',
    '红槽接走初始红沙': 'Use the red pit to collect the starting red sand', '红色沙槽需绕行': 'Move the red pit around the obstacle',
    '绿色沙槽可穿过绿色地块': 'The green pit can pass through green tiles', '管道沙接完后沙袋消失': 'The sandbag disappears when the pipe is emptied',
    '冰冻层数减少后再接沙': 'Wait for the ice to melt before collecting more sand', '右槽才能上移接沙': 'Move the right pit up to collect the sand',
    '依次填满门上方的三个沙槽': 'Fill the three pits above the gate in order', '左侧四个沙槽依次接满': 'Fill the four pits on the left in order',
    '每填满一个沙槽': 'Each time you fill a pit', '沙池排空后两秒补回': 'The sand pool refills two seconds after it is emptied',
    '沙槽可穿过原占格': 'Pits can pass through spaces they previously occupied', '沙槽容量较大': 'This pit holds more sand',
    '沙袋解开消失并释放占格': 'The sandbag disappears when unlocked, freeing its space', '被锁住的串不能移动': 'Locked skewers cannot be moved',
    '被锁住的串只能放相同水果': 'Only matching fruit can be placed on a locked skewer', '被锁住的糖葫芦不能移动': 'Locked candied-hawthorn skewers cannot be moved',
    '放到同色串': 'Place it on a matching skewer', '签子数量已达上限': 'The skewer is full', '糖葫芦移动中': 'Moving the skewer',
    '合成任意串串即可过关': 'Complete any skewer to clear the level', '解锁糖纸后可打开': 'Unlock the wrapper to open it',
    '观察下一层外框与剩余层数': 'Watch the outline and remaining layers', '观察大卷帘门倒数': 'Watch the roller door countdown',
    '观察平台打开': 'Watch the platform open', '观察整组一起移动': 'Watch the group move together', '观察时钟飞行和加时': 'Watch the clock fly and add time',
    '观察桌布解除': 'Watch the tablecloth lift', '观察碎片的缺口': 'Look for the missing piece', '观察碰撞和接沙': 'Watch how the pits collide and collect sand',
    '观察管道持续补入沙池': 'Watch the pipe keep refilling the sand pool', '观察糖果棒收缩': 'Watch the candy cane shrink',
    '观察联动拖动': 'Watch the linked pits move together', '观察自动解锁': 'Watch it unlock automatically', '观察隔空吸沙': 'Watch the magnet pull in sand',
    '观察飞锤击碎右侧岩石': 'Watch the flying hammer break the rock on the right', '点击转盘验证': 'Tap the wheel to check',
    '点击转盘可以放弃回想': 'Tap the wheel to stop recalling', '点击可放弃回想': 'Tap to stop recalling', '回想倒计时': 'Recall countdown',
    '秒回想时间': 'sec to recall', '时间耗尽或验证次数用完则挑战失败': 'The challenge fails when time or attempts run out',
    '透视可翻开一个藏起来的罐子': 'Peek inside one hidden jar', '相邻的两个格子可以斜着连': 'You can connect diagonally adjacent spaces',
    '连线之间可以交叉': 'Lines may cross each other', '连上所有数字才能过关': 'Connect every number to clear the level',
    '还有中间数字没有连上': 'Some numbers in the middle are still unconnected', '连到带钥匙的格子收集钥匙': 'Connect to the key space to collect the key',
    '把这些格子连起来': 'Connect these spaces', '选择要消除的颜色': 'Choose a color to clear', '请选择一种颜色': 'Choose a color',
    '分享未完成': 'Sharing was cancelled', '订阅成功': 'Subscribed successfully', '订阅失败': 'Subscription failed',
    '订阅未完成': 'Subscription cancelled', '订阅奖励已领取': 'Subscription reward claimed', '当前抖音版本不支持订阅': 'This Douyin version does not support subscriptions',
    '请升级抖音后重试': 'Update Douyin and try again', '请从侧边栏进入后领取': 'Open the sidebar to claim this reward',
    '跳转中': 'Opening', '跳转失败': 'Could not open', '跳转关卡': 'Go to Level', '选择关卡': 'Select a Level',
    '分享状态保存失败': 'Could not save the sharing status', '领取失败': 'Could not claim reward', '领取成功': 'Reward claimed',
    '连签进度': 'Check-In Streak', '连签再加一天': 'Add another day to your streak', '连签小达人': 'Check-In Pro',
    '签到日历翻好页': 'Your check-in calendar is ready', '签到进度已存好': 'Check-in progress saved', '明天一定来': 'Be sure to come back tomorrow',
    '明天份的快乐预约成功': 'Tomorrow’s fun is reserved', '明天也要元气满满来签到': 'Come back tomorrow for another check-in',
    '每天来一次': 'Come back once a day', '你今天超准时': 'You’re right on time today', '正在加载': 'Loading', '收起': 'Collapse',
    '金币越攒越多': 'Your coins are adding up', '继续变富有': 'Keep getting richer', '七日大礼在向你招手': 'A seven-day reward is waiting for you',
    '快乐翻倍': 'Double the fun', '大奖就在前面': 'The grand prize is just ahead', '好运不停歇': 'Keep the good luck coming',
    '华容道王者': 'Sliding Puzzle Master', '拼图小能手': 'Puzzle Pro', '消消乐达人': 'Match Master', '沙子大师': 'Sand Master',
    '图案罐': 'Pattern Jar', '午后咖啡': 'Afternoon Coffee', '富有之路': 'Road to Riches', '夜猫子': 'Night Owl', '玻璃玉石': 'Glass Gem',
    '猜猜明天有什么': 'Guess what tomorrow will bring', '金币叮当响': 'Coins are jingling', '金币罐子还没满': 'The coin jar is not full yet',
    '闪闪金币': 'Shiny Coins', '锤子道具': 'Hammer', '磁铁道具': 'Magnet', '魔杖': 'Magic Wand', '时间冻结道具': 'Time Freeze',
    '间隔': 'Spacing', '倍数': 'Multiplier', '正确': 'Correct', '剩余': 'Remaining', '取下一个': 'Take the next one', '再取下一个': 'Take the next one',
    '已跳转': 'Opened', '处理中': 'Processing', '请稍后重试': 'Please try again later', '确定': 'Confirm', '收起': 'Collapse',
    "所有问号": "All ? Tiles",
    "SeegSDK测试": "SeegSDK Test",
    "暖暖针织": "Cozy Knit",
    "暂停15秒": "Pause for 15 seconds",
    "蝴蝶翩翩": "Flutter Wings",
    "道具": "Boosters",
    "今日奖励已领取": "Today's reward claimed",
    "打开仙人掌教学": "Open Cactus Tutorial",
    "自动玩：关": "Auto Play: Off",
    "雪夜小屋": "Snowy Cabin",
    "更新提示": "Update Available",
    "观看视频获得道具": "Watch an ad for a booster",
    "锁": "Lock",
    "消除全盘同颜色的沙子！": "Clear all sand of one color!",
    "填满一个沙槽，解除其他沙槽的连接！": "Fill a tray to unlink the other trays!",
    "上一步": "Previous Move",
    "甜品小镇": "Sweet Town",
    "点一格，揭开周围数字！": "Tap a tile to reveal nearby numbers!",
    "增加120秒": "Add 120 seconds",
    "翻开一个藏起来的瓶子！": "Reveal a hidden bottle!",
    "撤回": "Undo",
    "墙壁挡住了沙子，用大锤将它击碎！": "A wall blocks the sand. Break it with the hammer!",
    "剪刀": "Scissors",
    "用于购买商店中的通用道具": "Use these to buy boosters in the shop",
    "只有同色沙槽能穿过彩色地砖！": "Only trays of the matching color can cross colored tiles!",
    "用于进入关卡": "Use this to enter a level",
    "顶部关卡标题：关": "Top Level Title: Off",
    "抛出报错": "Trigger Error",
    "免广告：关": "No Ads: Off",
    "点一格，揭开周围数字": "Tap a tile to reveal nearby numbers",
    "空签子": "Empty Skewer",
    "自动向容器补沙，沙子耗尽后消失！": "Automatically refills the container. Disappears when empty!",
    "沙袋装着沙子，倒空后就会消失！": "Sandbags hold sand and disappear when emptied!",
    "默认视频": "Default Video",
    "蘑菇森林": "Mushroom Woods",
    "Debug 数据源：关闭": "Debug Data Source: Off",
    "加空签": "Add Skewer",
    "云海城堡": "Cloud Castle",
    "时间冻结 +10s": "Time Freeze +10s",
    "拼合": "Join",
    "经典糖果": "Candy Classic",
    "主播设置": "Creator Settings",
    "永远当做新人：关": "Always New Player: Off",
    "木质积木": "Wooden Blocks",
    "经典星光": "Classic Stars",
    "剪断最上层的一根绳子！": "Cut the top rope!",
    "点击糖葫芦": "Tap the Candied Fruit",
    "亮部": "Highlights",
    "蕾丝花语": "Floral Lace",
    "邀请一人": "Invite One Friend",
    "糖果泡泡": "Candy Bubbles",
    "正确位置": "Correct Position",
    "亮度": "Brightness",
    "看3次视频，3小时内猜瓶子无限时间！": "Watch 3 ads for 3 hours of unlimited time in Guess the Bottle!",
    "加时": "Add Time",
    "暗部": "Shadows",
    "糖纸": "Candy Wrapper",
    "奇数": "Odd",
    "爱心泡泡": "Heart Bubbles",
    "彩虹云朵": "Rainbow Clouds",
    "领取失败，请重试": "Couldn't claim. Try again.",
    "揭开所有问号遮罩！": "Reveal every ? tile!",
    "分裂所选坑位！": "Split the selected tray!",
    "分裂": "Split",
    "直接串好一串糖葫芦！": "Complete one candied fruit skewer instantly!",
    "炫彩金属": "Shiny Metal",
    "喵喵爪印": "Kitty Paws",
    "对照组：自动": "Control Group: Auto",
    "珐琅彩瓷": "Enamel Porcelain",
    "打开游戏结束": "Open Game Over",
    "琉璃": "Colored Glass",
    "获取 1000 金币": "Get 1000 Coins",
    "标出一个瓶子的正确位置！": "Show the correct position of one bottle!",
    "同颜色": "Same Color",
    "自动拼合一对相邻碎片！": "Automatically join two adjacent pieces!",
    "隐藏 Debug": "Hide Debug",
    "南瓜幽灵": "Pumpkin Spirits",
    "樱花庭院": "Sakura Garden",
    "打开复活弹窗": "Open Revive Popup",
    "蝙蝠南瓜": "Bats & Pumpkins",
    "Q弹果冻": "Bouncy Jelly",
    "经典紫": "Classic Purple",
    "显示": "Show",
    "别笑，你也过不去第二关！": "Think you can beat Level 2?",
    "樱花纷飞": "Sakura Petals",
    "消除": "Clear",
    "范围提示": "Area Hint",
    "沙丘波纹": "Dune Ripples",
    "星愿魔法": "Star Magic",
    "海底珊瑚": "Coral Reef",
    "填满": "Fill",
    "倒计时增加60秒！": "Add 60 seconds to the timer!",
    "透视": "X-Ray",
    "先填满内层沙槽，解锁下方的沙槽！": "Fill the inner tray first to unlock the tray below!",
    "文字书画": "Calligraphy",
    "星空乐园": "Star Carnival",
    "星光菱格": "Star Argyle",
    "黄金卡组": "Golden Deck",
    "打开新玩法弹窗": "Open New Mode Popup",
    "领取失败，请稍后重试": "Couldn't claim. Try again later.",
    "强制更新": "Force Update",
    "暂无吸量关卡": "No Promo Levels Available",
    "问号罐": "Mystery Jar",
    "玩法测试": "Gameplay Test",
    "打开沙泵教学": "Open Sand Pump Tutorial",
    "##倍数": "## Multiplier",
    "蝴蝶结礼物": "Bow Gifts",
    "填满沙槽，击碎冰层！": "Fill the tray to break the ice!",
    "月夜沙漠": "Moonlit Desert",
    "收集对应的钥匙，打开锁！": "Collect matching keys to open the lock!",
    "光滑度": "Smoothness",
    "玻璃挡住了容器，清除玻璃才能收集沙子！": "Glass blocks the container. Clear it to collect the sand!",
    "只能沿箭头方向拖动沙槽！": "Drag trays only in the direction of their arrows!",
    "怀旧": "Retro",
    "切换沙子音效": "Change Sand Sound",
    "间隔##": "Interval ##",
    "薰衣草田": "Lavender Field",
    "热门影视": "Popular Shows",
    "增加60秒": "Add 60 seconds",
    "填满沙槽，揭开桌布！": "Fill the tray to reveal the tablecloth!",
    "串好一串": "Complete Skewer",
    "去遮罩": "Remove Cover",
    "万圣之夜": "Halloween Night",
    "没有找到可合成的碎片": "No matching pieces found",
    "翻开": "Reveal",
    "填满并消除时钟槽，获得额外时间！": "Fill and clear a clock tray for extra time!",
    "补满局内道具": "Refill Boosters",
    "吸量关卡": "Promo Levels",
    "可以将时间暂停15秒！": "Pause the timer for 15 seconds!",
    "按住并拖动，取出沙槽；全部取出后，生成器会消失！": "Hold and drag to take out trays. Empty the generator to make it disappear!",
    "周围数字": "Nearby Numbers",
    "清空平台，让新的沙槽升上来！": "Clear the platform to raise new trays!",
    "撤回上一步操作！": "Undo your last move!",
    "璀璨水晶": "Bright Crystal",
    "有效期内进入关卡不消耗体力": "Enter levels without spending stamina while active",
    "填满与糖果同色的沙槽，磨掉糖果！": "Fill a tray matching the candy's color to wear it away!",
    "打开沙袋教学": "Open Sandbag Tutorial",
    "填满沙槽，让仙人掌缩回去！": "Fill the tray to make the cactus retract!",
    "海边灯塔": "Coastal Beacon",
    "填满沙槽，打开卷帘门！": "Fill the tray to open the shutter!",
    "清空数据": "Clear Data",
    "草莓甜心": "Sweet Strawberry",
    "逐层填满内层沙槽，清空整层沙槽！": "Fill the inner trays layer by layer to clear the whole layer!",
    "转了个沙关卡源：side-game": "Sand Spin Level Source: side-game",
    "梦幻泡泡": "Dream Bubbles",
    "显示一个隐藏的数字！": "Reveal one hidden number!",
    "剪断": "Cut",
    "吸量关卡不可用": "Promo Levels Unavailable",
    "偶数": "Even",
    "增加一根空签子！": "Add one empty skewer!",
    "容器中的沙减少时，管道会自动补沙！": "The pipe automatically refills sand as the container empties!",
    "甜心波点": "Sweet Polka Dots",
    "倒计时增加120秒！": "Add 120 seconds to the timer!",
    "看完视频，才能获取奖励": "Finish watching the ad to get your reward",
    "马卡龙派对": "Macaron Party",
    "重试云存档": "Retry Cloud Save",
    "今日次数已用完，明天再来": "Today's limit reached. Come back tomorrow.",
    "明天见呀，奖励给你留着啦~": "See you tomorrow! Your rewards will be waiting.",
    "今天签过啦，明天再来哦~": "Already checked in today. See you tomorrow!",
    "金币在打包，明天来拿呀！": "Your coins are getting packed. Pick them up tomorrow!",
    "道具们在等你，明天见~": "Your boosters are waiting. See you tomorrow!",
    "明天签到更惊喜，不见不散！": "More surprises tomorrow. Don't miss them!",
    "别忘啦，明天还有好礼哦~": "Don't forget tomorrow's rewards!",
    "休息一下，明天继续签到呀~": "Take a break. Check in again tomorrow!",
    "明天也要来找我玩呀~": "Come play with me again tomorrow!",
    "连签不断，大奖就在前面！": "Keep your daily streak for bigger rewards!",
    "小锤子说：明天等你哦~": "Your hammer says, see you tomorrow!",
    "磁铁说：明天把你吸回来~": "Your magnet will pull you back tomorrow!",
    "小闹钟定好啦，明天叫你~": "The alarm is set. See you tomorrow!",
    "今天的份领完啦，明天见！": "Today's rewards are claimed. See you tomorrow!",
    "明天的金币已经在路上啦~": "Tomorrow's coins are on their way!",
    "攒好力气，明天再来签到~": "Rest up and check in tomorrow!",
    "明天来，礼物更多一点哦~": "Come back tomorrow for more gifts!",
    "签到进度已存好，明天见~": "Your check-in progress is saved. See you tomorrow!",
    "明天准时来，奖励不跑哦~": "Come back on time tomorrow. Your rewards will be here!",
    "今天超棒！明天继续加油~": "Great job today! Keep it up tomorrow!",
    "沙子们说：明天还想见你~": "The sand wants to see you again tomorrow!",
    "明天的惊喜正在装盒中~": "Tomorrow's surprise is getting wrapped!",
    "一天一签，好运连连哦~": "Check in daily and keep the good luck going!",
    "约好啦，明天同一时间见~": "Same time tomorrow? It's a date!",
    "明天来签到，金币叮当响~": "Check in tomorrow for more jingling coins!",
    "小道具们排好队等你啦~": "Your boosters are lined up and ready!",
    "别断签哦，明天记得来~": "Keep your streak going. Come back tomorrow!",
    "断签要重头来，明天见呀~": "Miss a day and your streak resets. See you tomorrow!",
    "坚持签到，第7天有大礼！": "Keep checking in for a big Day 7 reward!",
    "离大礼又近一步啦，明天见~": "One step closer to the big reward. See you tomorrow!",
    "明天再来，继续攒奖励~": "Come back tomorrow and keep earning!",
    "今天收获满满，明天继续~": "Great haul today! Let's do it again tomorrow!",
    "金币罐子还没满，明天来~": "Your coin jar isn't full yet. Come back tomorrow!",
    "明天的签到卡已经亮灯啦~": "Tomorrow's check-in card is ready!",
    "睡个好觉，明天来领奖~": "Sleep well. Come claim your reward tomorrow!",
    "明天见！我会想你的~": "See you tomorrow! I'll miss you!",
    "签到小本本记下你啦~": "You're in the check-in book!",
    "明天还有新奖励等着你~": "A new reward is waiting tomorrow!",
    "连签小达人，明天继续！": "Check-in champ! Keep it going tomorrow!",
    "明天来，锤子给你留好啦~": "Your hammer will be waiting tomorrow!",
    "明天来，磁铁给你备好啦~": "Your magnet is ready for tomorrow!",
    "明天来，加时道具在等你~": "A time booster is waiting tomorrow!",
    "今天任务完成，撒花~明天见": "Today's task is done. Hooray! See you tomorrow!",
    "奖励已到账，明天再来呀~": "Reward delivered! Come back tomorrow!",
    "每天来一次，好运不停歇~": "Visit daily and keep the good luck coming!",
    "明天的你会更幸运哦~": "Tomorrow could be your lucky day!",
    "先去玩两关，明天再签到~": "Go play a few levels. Check in again tomorrow!",
    "去闯关吧，明天记得签到~": "Go clear some levels! Remember to check in tomorrow!",
    "今天领过啦，去玩关卡吧~": "Already claimed today. Go play some levels!",
    "沙子堆好啦，明天来收礼~": "The sand is ready. Come get your gift tomorrow!",
    "小金币在打盹，明天叫醒它~": "Your coins are napping. Wake them tomorrow!",
    "明天的礼物偷偷变大啦~": "Tomorrow's gift just got a little bigger!",
    "嘘~明天的奖励是个秘密": "Shh! Tomorrow's reward is a secret.",
    "猜猜明天有什么？来看看~": "What's coming tomorrow? Come find out!",
    "签到日历翻好页，等你哦~": "Your check-in calendar is ready for you!",
    "明天打卡，继续变富有~": "Check in tomorrow and keep building your stash!",
    "富有之路，明天继续走~": "Keep growing your coin stash tomorrow!",
    "金币越攒越多，明天见~": "Your coins are adding up. See you tomorrow!",
    "明天来，连签再加一天！": "Come back tomorrow and add another day to your streak!",
    "连签进度+1，明天见啦~": "Check-in streak +1. See you tomorrow!",
    "你今天超准时，明天也是哦": "Right on time today! Do it again tomorrow.",
    "明天也要元气满满来签到~": "Bring that energy to tomorrow's check-in!",
    "元气签到，明天不见不散~": "Ready for more? See you at tomorrow's check-in!",
    "明天的签到等你来点亮~": "Tomorrow's check-in is waiting for you!",
    "一起坚持七天吧，明天见~": "Let's make it seven days! See you tomorrow!",
    "七天之约，明天继续~": "Our seven-day streak continues tomorrow!",
    "七日大礼在向你招手~": "Your Day 7 reward is calling!",
    "今天份的快乐已领取~": "Today's dose of fun is claimed!",
    "明天份的快乐预约成功~": "Tomorrow's fun is reserved!",
    "预约成功！明天来领奖~": "You're all set! Claim your reward tomorrow!",
    "明天准时报到哦，么么哒~": "Be here on time tomorrow. See you then!",
    "明天来抱抱新奖励吧~": "Come back for a new reward tomorrow!",
    "今天辛苦啦，明天见~": "Nice work today. See you tomorrow!",
    "奖励不会跑，明天慢慢来~": "Your rewards aren't going anywhere. See you tomorrow!",
    "明天一睁眼，记得来签到~": "Remember to check in when you wake up tomorrow!",
    "起床第一件事：来签到~": "First thing tomorrow: check in!",
    "明天也要来看看我呀~": "Come see me again tomorrow!",
    "我在这里等你，明天见~": "I'll be here waiting. See you tomorrow!",
    "小磁铁吸住你的明天啦~": "Your magnet has a hold on tomorrow!",
    "小锤子敲敲：明天来哦~": "Knock, knock! Your hammer says, come back tomorrow!",
    "闹钟滴答滴，明天来签到~": "Ticktock! Time to check in tomorrow!",
    "时间冻结不了，明天见~": "Can't freeze tomorrow. See you then!",
    "明天的沙子更闪亮哦~": "Tomorrow's sand will shine even brighter!",
    "闪闪金币，明天再领~": "More shiny coins to claim tomorrow!",
    "今天满分！明天继续冲~": "Perfect day! Keep it going tomorrow!",
    "明天来，继续好运buff~": "Come back tomorrow for more good luck!",
    "好运已充能，明天来释放~": "Your luck is charged. Use it tomorrow!",
    "明天签到，手气更好哦~": "Check in tomorrow for another lucky day!",
    "坚持就是胜利，明天见~": "Keep at it! See you tomorrow!",
    "离第7天越来越近啦~": "Getting closer to Day 7!",
    "大礼包在终点等你哦~": "A big reward is waiting at the finish!",
    "明天签一下，开心一整天~": "Check in tomorrow for a happy day!",
    "签到一下，快乐翻倍~": "Check in and double the fun!",
    "明天见！带上好心情来~": "See you tomorrow! Bring a smile!",
    "今天份已签收，谢谢你~": "Today's reward is received. Thank you!",
    "明天的奖励已在排队啦~": "Tomorrow's reward is already lined up!",
    "排队中…明天轮到你领奖~": "You're in line! Tomorrow it's your turn to claim!",
    "明天来，不要放我鸽子哦~": "Don't stand me up. Come back tomorrow!",
    "拉钩钩，明天一定来~": "Pinky promise you'll come tomorrow!",
    "说好了，明天见不散~": "It's a deal. See you tomorrow!",
    "晚安~明天签到见啦": "Good night! See you at tomorrow's check-in.",
    "解锁失败，请稍后再试": "Could not unlock. Try again later.",
    "账号同步中，请稍后再试": "Syncing your account. Try again shortly.",
    "本期奖励已全部达成！": "All rewards earned for this round!",
    "连续获胜可提升倍率！失败会回到 x1": "Win to boost your multiplier! Losing resets it to x1.",
    "2. 每通关一个主线关卡即可获得卡牌，获得数量等于当前倍率。": "2. Clear main levels to earn cards equal to your current multiplier.",
    "4. 闯关失败、重新挑战或中途返回首页，倍率回到 x1，已获得的卡牌不会减少。": "4. Losing, restarting, or returning home resets your multiplier to x1. You keep cards already earned.",
    "5. 卡牌累计达到目标即可领取对应奖励；新一期开始后进度重置，请及时领取。": "5. Earn enough cards to claim each reward. Progress resets each round, so claim rewards before it ends.",
    "创意玩法制作中，敬请期待": "New modes are coming soon!",
    "玩法加载失败，请重试": "Could not load this mode. Try again.",
    "待开发…": "Coming Soon…",
    "反馈功能暂未开放，感谢支持": "Feedback is not available yet. Thanks for your support!",
    "进入失败，请再试一次": "Could not open this mode. Try again.",
    "数据已清空": "Data cleared",
    "网络不佳，道具未消耗，请重试": "Connection failed. Your booster was not used. Try again.",
    "页面加载失败，请重试": "Could not load this page. Try again.",
    "云存档暂不可用，请稍后重试": "Cloud save unavailable. Try again later.",
    "刷新成功": "Refreshed",
    "视频暂不可用，请稍后重试": "Video unavailable. Try again later.",
    "请完整观看视频后领取奖励": "Watch the full video to claim your reward.",
    "云存档已恢复": "Cloud save restored",
    "今天已经签到过了，明天再来吧": "Already checked in. Come back tomorrow.",
    "体力状态已变化，请重试": "Stamina changed. Please try again.",
    "暂时无法切换关卡": "Cannot switch levels right now.",
    "账号同步中，请稍后再领取": "Syncing account. Please try again shortly.",
  });

  const patterns = [
    [/^自动\((.+)\)$/, 'Auto ($1)'],
    [/^观看广告即可解锁副玩法当日体验权限（主玩法通过第(\d+)关后，可免广告直接体验）$/, 'Watch an ad to try this mode today.\nClear Level $1 to play without ads.'],
    [/^无限时间 (\d+)\/(\d+)$/, 'Unlimited Time $1/$2'],
    [/^无限时间 剩余 (.+)$/, 'Time Left: $1'],
    [/^新手教学 (\d+)\/(\d+)$/, 'Tutorial $1/$2'],
    [/^第(\d+)–(\d+)关$/, 'Levels $1–$2'],
    [/^玩家(.+)$/, 'Player $1'],
    [/^获取(.+)$/, (_, name) => 'Get ' + translate(name)],
    [/^(.+)当日体验$/, (_, name) => 'Try ' + translate(name) + ' today'],
    [/^副玩法-第(\d+)关$/, 'Side Mode - Level $1'],
    [/^主页-超好玩-(.+)$/, (_, name) => 'Home - ' + translate(name)],
    [/^主线-第(\d+)关$/, 'Level $1'],
    [/^(.+)体验过期回主页$/, (_, name) => translate(name) + ' trial expired. Back to Home.'],
    [/^转了个沙关卡源：(.+)$/, 'Sand Spin source: $1'],
    [/^对照组：(.+)$/, (_, value) => 'Control Group: ' + translate(value)],
    [/^Debug 数据源：(.+)$/, (_, value) => 'Debug Source: ' + translate(value)],
    [/^(.+)：(.+)，可在设置中重开或返回首页$/, (_, name, result) => translate(name) + ': ' + translate(result) + '. Restart or return Home in Settings.'],
    [/^静态预览 (.+) 装配失败: (.+)$/, 'Could not assemble preview $1: $2'],
    [/^猜瓶子关卡加载失败：(.+)$/, 'Could not load Guess the Cans level: $1'],
    [/^\[LevelTip\] art 字关卡号加载失败 level=(.+)$/, '[LevelTip] Could not load level artwork: $1'],

    [/^再加(\d+)秒，继续游戏$/, 'Add $1s to keep playing!'],
    [/^再加(\d+)次验证和(\d+)秒，继续游戏$/, 'Add $1 checks and $2s!'],
    [/^恢复(\d+)颗心，继续游戏$/, 'Restore $1 heart to keep playing'],
    [/^第(\d+)关$/, 'Level $1'],
    [/^第(\d+)关完成$/, 'Level $1 Complete'],
    [/^第(\d+)关失败$/, 'Level $1 Failed'],
    [/^第(\d+)关\s*$/, 'Level $1'],
    [/^获得金币\s*x?(\d+)$/, 'Earned $1 coins'],
    [/^获得\s*(\d+)金币$/, 'Earned $1 coins'],
    [/^获得\s*(.+)\s*x(\d+)$/, 'Earned $1 × $2'],
    [/^获得\s*(.+)$/, 'Earned $1'],
    [/^今日剩余\s*(\d+)次$/, '$1 attempts left today'],
    [/^今日剩余\s*(\d+)$/, '$1 remaining today'],
    [/^还剩\s*(\d+)秒$/, '$1 sec remaining'],
    [/^再加\s*(\d+)秒$/, 'Add $1 sec'],
    [/^失去\s*(\d+)个体力$/, 'Lose $1 stamina'],
    [/^你将失去\s*(\d+)个体力$/, 'You will lose $1 stamina'],
    [/^通关第\s*(\d+)关后开启$/, 'Unlock after clearing Level $1'],
    [/^主玩法通过第\s*(\d+)关后$/, 'Available after clearing main Level $1'],
    [/^主玩法通过第\s*(\d+)关后可免广告直接体验$/, 'Play free of ads after clearing main Level $1'],
    [/^累计分享\s*(\d+)人进入游戏$/, '$1 friends joined through your invites'],
    [/^连续获胜\s*(\d+)场$/, '$1 consecutive wins'],
    [/^第\s*(\d+)天$/, 'Day $1'],
    [/^已获得\s*(\d+)金币$/, '$1 coins earned'],
    [/^x(\d+)$/, '×$1']
  ];

  patterns.unshift([/^版本号[：:]\s*(.*)$/, 'Version: $1']);
  patterns.unshift([/^关卡\s*(\d+)$/, 'Level $1']);
  patterns.unshift(
    [/^商店刷新[：:]\s*(.*)$/, 'Refresh: $1'],
    [/^(\d+)分钟$/, '$1 min'],
    [/^\+(\d+)体力$/, '+$1 Stamina'],
    [/^奖励 \+(\d+)$/, '+$1 Coins'],
    [/^体验(\d+)\/(\d+)$/, 'Trial $1/$2'],
    [/^今日剩余 (\d+)\/(\d+) 次$/, '$1/$2 left today']
  );
  patterns.unshift(
    [/^正确(\d+)个$/, '$1 correct'],
    [/^应在(.+)$/, 'Expected: $1'],
    [/^剩(\d+)次$/, '$1 tries left'],
    [/^累计分享\s*(\d+)人进入游戏$/, 'Invite $1 friends to play'],
    [/^剩余时间[：:]\s*(.*)$/, (_, value) => 'Time left: ' + translate(value)],
    [/^通关第\s*(\d+)\s*关后开启$/, 'Unlock after Level $1'],
    [/^累计\s*(\d+)$/, 'Total $1'],
    [/^已看(\d+)\/(\d+)$/, 'Watched $1/$2'],
    [/^解锁(\d+)\/(\d+)$/, 'Unlock $1/$2'],
    [/^或通过第(\d+)关$/, 'Or clear Level $1'],
    [/^目标\s*(\d+)$/, 'Goal: $1'],
    [/^ID[：:]\s*(.*)$/, 'ID: $1'],
    [/^(\d+)%\n折扣$/, '$1%\nOFF']
  );
  patterns.unshift(
    [new RegExp("^\u901a\u5173\u4e3b\u73a9\u6cd5\u7b2c\\s*(\\d+)\\s*\u5173\u89e3\u9501$"), "Clear main Level $1 to unlock"],
    [new RegExp("^\u901a\u5173\u7b2c\\s*(\\d+)\\s*\u5173\u89e3\u9501$"), "Unlock after Level $1"],
    [new RegExp("^1\\. \u901a\u5173\u7b2c (\\d+) \u5173\u540e\u5f00\u542f\u6d3b\u52a8\uff0c\u6bcf\u5468\u4e00\u3001\u5468\u4e94 16:00 \u5f00\u542f\u65b0\u4e00\u671f\u3002$"), "1. Unlock after Level $1. New rounds start Monday and Friday at 16:00."],
    [new RegExp("^3\\. \u8fde\u7eed\u901a\u5173\u500d\u7387\u9010\u6863\u63d0\u5347\uff0c\u6700\u9ad8 x(\\d+)\u3002$"), "3. Consecutive wins increase your multiplier, up to x$1."],
    [new RegExp("^\u65e0\u9650\u4f53\u529b\\s*(\\d+)\u5206\u949f$"), "Unlimited \u00b7 $1 min"],
    [new RegExp("^\u91d1\u5e01\\s*[\u00d7x]\\s*(\\d+)$"), "Coins \u00d7$1"],
    [new RegExp("^\u65f6\u95f4\u51bb\u7ed3\\s*[\u00d7x]\\s*(\\d+)$"), "Time Freeze \u00d7$1"],
    [/^再看 (\d+) 次视频解锁「(.+)」$/, (_, count, name) => `Watch ${count} more ads to unlock ${translate(name)}`],
    [/^已装备「(.+)」$/, (_, name) => `Equipped: ${translate(name)}`],
    [/^(\d+)天(\d+)小时$/, "$1d $2h"],
    [/^(\d+)小时(\d+)分$/, "$1h $2m"],
    [/^(\d+)分(\d+)秒$/, "$1m $2s"]
  );
  patterns.unshift(
    [/^获得\s+(.+)$/, (_, value) => 'You Got ' + translate(value)],
    [/^(.+?)\s*[×x]\s*(\d+)$/, (_, name, count) => translate(name.trim()) + ' ×' + count]
  );
  let language = 'en';
  const originalText = new WeakMap();
  const localizedImages = new Set();
  const languageListeners = new Set();
  function registerImage(node, english, original = node.src) {
    const item = {node, original, english};
    localizedImages.add(item);
    node.src = language === 'en' ? english : item.original;
  }
  let descriptor = null;
  const translate = value => {
    const source = String(value == null ? '' : value);
    if (language === 'zh-CN' || !source) return source;
    if (Object.prototype.hasOwnProperty.call(en, source)) return en[source];
    if (source.includes('\n')) return source.split('\n').map(translate).join('\n');
    // Match the whole sentence before reconstructing its color spans. Translating
    // fragments separately loses word order and leaves Chinese rich-text tails.
    if (/\[(?:color|b|i|u|size|font)(?:=[^\]]+)?\]/i.test(source)) {
      const plain = source.replace(/\[\/?(?:color|b|i|u|size|font)(?:=[^\]]+)?\]/gi, '');
      if (plain !== source) {
        let translated = translate(plain);
        if (translated !== plain) {
          const spans = [...source.matchAll(/\[color=([^\]]+)\]([\s\S]*?)\[\/color\]/gi)];
          for (const [, color, raw] of spans) {
            const highlight = translate(raw);
            const index = translated.toLowerCase().indexOf(highlight.toLowerCase());
            if (index >= 0 && highlight) translated = translated.slice(0,index) + '[color=' + color + ']' + translated.slice(index,index+highlight.length) + '[/color]' + translated.slice(index+highlight.length);
            else if (spans.length === 1) translated = '[color=' + color + ']' + translated + '[/color]';
          }
          return translated;
        }
      }
    }
    for (const [pattern, replacement] of patterns) {
      if (pattern.test(source)) return source.replace(pattern, replacement);
    }
    return source;
  };

  function refreshTree(node) {
    if (!node) return;
    const Text = window.Laya && Laya.Text;
    if (Text && node instanceof Text && descriptor && descriptor.set) {
      if (!originalText.has(node)) originalText.set(node, String(node.text || ""));
      descriptor.set.call(node, translate(originalText.get(node)));
    }
    const children = node._children || node.children;
    if (children && typeof children.length === 'number') {
      for (let i = 0; i < children.length; i++) refreshTree(children[i]);
    }
  }

  function install() {
    const Text = window.Laya && Laya.Text;
    if (!Text || !Text.prototype) return false;
    const d = Object.getOwnPropertyDescriptor(Text.prototype, 'text');
    if (!d || !d.set || Text.prototype.__sandI18nInstalled) return !!Text.prototype.__sandI18nInstalled;
    descriptor = d;
    Object.defineProperty(Text.prototype, 'text', {
      configurable: d.configurable,
      enumerable: d.enumerable,
      get: d.get,
      set(value) {
        const raw = String(value == null ? '' : value);
        originalText.set(this, raw);
        return d.set.call(this, translate(raw));
      }
    });
    Object.defineProperty(Text.prototype, '__sandI18nInstalled', {value: true});
    refreshTree(Laya.stage);
    return true;
  }

  function setLanguage(next) {
    language = next === 'zh-CN' ? 'zh-CN' : 'en';
    if(document.documentElement)if(document.documentElement)document.documentElement.lang = language;
    try { localStorage.setItem('block-maze-language-v2', language); } catch (_) {}
    const bootStatus = (document.getElementById?(document.getElementById?document.getElementById('boot-status'):null):null);
    if (bootStatus && !window.__sandBootLoaded) {
      bootStatus.textContent = language === 'zh-CN' ? '正在加载原版游戏…' : 'Loading the original game…';
    }
    install();
    refreshTree(window.Laya && Laya.stage);
    if (window.__sandAssetI18n) window.__sandAssetI18n.refresh();
    for (const item of fittedLabels) applyLabelFit(item);
    for (const callback of languageListeners) callback(language);
    dispatchEvent(new Event("sand-language-change"));
    for (const item of localizedImages) {
      if (item.node.destroyed) localizedImages.delete(item);
      else item.node.src = language === 'en' ? item.english : item.original;
    }
    if (window.parent !== window) window.parent.postMessage({type: 'sand-puzzler-ready', language}, '*');
  }

  function mountSettingsLanguage(view, y) {
    if (!view.content) return y;
    let button = view.__languageButton;
    if (!button || button.destroyed) {
      button = view.__languageButton = new Laya.GButton();
      const label=new Laya.GTextField();label.name="LanguageCaption";label.mouseThrough=true;label.size(600,72);label.font=Laya.Config.defaultFont;label.fontSize=44;label.color="#ffffff";label.align="center";label.valign="middle";button.addChild(label);
      button.name = 'LanguageSetting';
      button.font = Laya.Config.defaultFont;
      button.fontSize = 44;
      button.color = '#ffffff';
      button.align = 'center'; button.valign = 'middle';
      button.size(600, 72); button.mouseEnabled = true;
      button.graphics.drawRoundRect(0, 0, 600, 72, 24, 24, 24, 24, '#7154cf');
      button.on(Laya.Event.CLICK, view, function(event) {
        event.stopPropagation();
        setLanguage(language === 'en' ? 'zh-CN' : 'en');
        button.getChildByName('LanguageCaption').text = language === 'en' ? 'Language: English  ›' : '语言：简体中文  ›';
      });
      view.content.addChild(button);
    }
    button.getChildByName('LanguageCaption').text = language === 'en' ? 'Language: English  ›' : '语言：简体中文  ›';
    button.pos((view.content.width - 600) / 2, y + 20);
    if(!view.__settingsLanguageRefresh){
      const refresh=()=>{const languageButton=view.__languageButton,profileButton=view.__rankingProfileButton;
        if(languageButton&&!languageButton.destroyed)languageButton.getChildByName('LanguageCaption').text=language==='en'?'Language: English  ›':'语言：简体中文  ›';
        if(profileButton&&!profileButton.destroyed)profileButton.getChildByName('ProfileCaption').text=language==='en'?'Leaderboard Profile  ›':'排行榜资料  ›';
      };
      view.__settingsLanguageRefresh=window.__sandI18n.onChange(refresh);
      view.once(Laya.Event.DESTROY,view,view.__settingsLanguageRefresh);
    }
    if(window.__blockLeaderboard){
      let profile=view.__rankingProfileButton;
      if(!profile||profile.destroyed){profile=view.__rankingProfileButton=new Laya.GButton();const caption=new Laya.GTextField();caption.name="ProfileCaption";caption.mouseThrough=true;caption.size(600,72);caption.font=Laya.Config.defaultFont;caption.fontSize=40;caption.color="#ffffff";caption.align="center";caption.valign="middle";profile.addChild(caption);profile.font=Laya.Config.defaultFont;profile.fontSize=40;profile.color='#ffffff';profile.align='center';profile.valign='middle';profile.size(600,72);profile.mouseEnabled=true;profile.on(Laya.Event.CLICK,view,event=>{event.stopPropagation();window.__blockLeaderboard.editProfile(true).catch(console.warn);});view.content.addChild(profile);}
      profile.getChildByName('ProfileCaption').text=language==='en'?'Leaderboard Profile  ›':'排行榜资料  ›';profile.pos((view.content.width-600)/2,y+110);return y+194;
    }
    return y + 104;
  }

  function mountResult(view) {
    const label = view.rewardGroup && view.rewardGroup.getChildByName('Label');
    const apply = () => {
      if (view.destroyed) return;
      const english = language === 'en';
      if (label) { label.text = english ? 'Reward' : '通关奖励'; label.fontSize = english ? 54 : 70; label.width = 300; label.overflow = 'shrink'; }
      if (view.title) view.title.visible = english || !view.titleSpineNode;
      if (view.titleSpineNode) view.titleSpineNode.visible = !english;
      if (view.winStreakBadge) view.winStreakBadge.setStreak(view.options.winStreak || 0);
    };
    apply();
    const stop = window.__sandI18n.onChange(apply);
    view.once(Laya.Event.DESTROY, view, stop);
  }

  // TikTok entrance missions are opened by the platform API; avoid obsolete Douyin screenshots.
  function mountEntranceGuide(view) {
    if (!view.content || view.__entranceGuideMounted) return;
    view.__entranceGuideMounted = true;
    for (const name of ['Step1Label','TabBar','Step2Label','RecentBox','Avatar']) {
      const node=view.content.getChildByName(name); if(node) node.visible=false;
    }
    const labels=[];
    function label(name,y,width,height,size,color,bg){
      const node=new Laya.Text();node.name=name;node.font=Laya.Config.defaultFont;node.fontSize=size;
      node.color=color;node.bold=true;node.align='center';node.valign='middle';node.wordWrap=true;
      node.size(width,height);node.pos(-width/2,y);node.mouseEnabled=false;
      if(bg)node.bgColor=bg;
      view.content.addChild(node);return node;
    }
    const step1=label('TikTokEntranceStep1',-530,800,90,34,'#79513a');
    const platform=label('TikTokEntrancePlatform',-435,800,120,58,'#ffffff','#191622');
    const step2=label('TikTokEntranceStep2',-295,800,110,34,'#79513a');
    const game=label('TikTokEntranceGame',-170,800,135,54,'#4e31a4','#ffffff');
    platform.text='TikTok';game.text='Block Maze';
    const apply=()=>{const en=language==='en';
      step1.text=en?'1. Tap Go to open TikTok’s game shortcut.':'1. 点击前往，打开 TikTok 游戏入口。';
      step2.text=en?'2. Return through the shortcut to claim your reward.':'2. 从该入口重新进入游戏，领取奖励。';
    };
    apply(); const stop=window.__sandI18n.onChange(apply);view.once(Laya.Event.DESTROY,view,stop);
  }

  const fittedLabels = new Set();
  function fitLabel(node, baseSize, width) {
    const item = {ref: new WeakRef(node), baseSize, width};
    fittedLabels.add(item); applyLabelFit(item);
  }
  function applyLabelFit(item) {
    const node = item.ref.deref();
    if (!node || node.destroyed) { fittedLabels.delete(item); return; }
    node.fontSize = item.baseSize;
    if (language === 'en' && node.textWidth > item.width - 16) node.fontSize = Math.max(24, Math.floor(item.baseSize * (item.width - 16) / node.textWidth));
  }
  let itemMeasureContext;
  function formatItemDescription(description, highlight) {
    if (language !== 'en') return highlight ? description.replace(highlight, '[color=#ffe644]' + highlight + '[/color]') : description;
    let translated = translate(description);
    if (!itemMeasureContext) itemMeasureContext = document.createElement('canvas').getContext('2d');
    itemMeasureContext.font = 'bold 40px "' + String(Laya.Config.defaultFont).replace(/"/g, '') + '", Arial';
    const lines = [];
    for (const paragraph of translated.split('\n')) {
      let line = '';
      for (const word of paragraph.split(/\s+/)) {
        const next = line ? line + ' ' + word : word;
        if (line && itemMeasureContext.measureText(next).width > 610) { lines.push(line); line = word; }
        else line = next;
      }
      lines.push(line);
    }
    translated = lines.join('\n');
    if (highlight) {
      const englishHighlight = translate(highlight);
      const index = translated.toLowerCase().indexOf(englishHighlight.toLowerCase());
      if (index >= 0) translated = translated.slice(0,index) + '[color=#ffe644]' + translated.slice(index,index+englishHighlight.length) + '[/color]' + translated.slice(index+englishHighlight.length);
      else translated = '[color=#ffe644]' + translated + '[/color]';
    }
    return translated;
  }
  window.__sandI18n = {setLanguage, get language() { return language; }, translate, install, mountSettingsLanguage, mountResult, registerImage, mountEntranceGuide, fitLabel, formatItemDescription, onChange(callback) { languageListeners.add(callback); return () => languageListeners.delete(callback); }};
  addEventListener('message', event => {
    if (event.data && event.data.type === 'sand-puzzler-language') setLanguage(event.data.language);
  });
  try {
    const saved = localStorage.getItem('block-maze-language-v2');
    if (saved === 'zh-CN' || saved === 'en') language = saved;
  } catch (_) {}
  install();
  if (window.parent !== window) window.parent.postMessage({type: 'sand-puzzler-ready', language}, '*');
  setInterval(install, 100);
})();
