/* Block Maze TikTok native candidate. No HTML entry, dynamic remote JS, or original developer login. */
'use strict';
const root=globalThis,config=require('./config.js');
if(!root.TTMinis||!TTMinis.game)throw Error('Open this package in the TikTok Mini Games runtime');
root.GameGlobal=root;root.window=root;const nativeHost=(root.tt&&typeof root.tt.createCanvas==='function')?root.tt:(root.wx&&typeof root.wx.createCanvas==='function')?root.wx:TTMinis.game;root.tt=nativeHost;
const paths=require('./module-map.js'),modules=new Map();
function norm(path){return String(path).replace(/^\.\//,'');}
function recoveredRequire(path){path=norm(path);if(!modules.has(path)){const physical=paths[path];if(!physical)throw Error('Unbundled executable: '+path);require('./'+physical);}const item=modules.get(path);if(!item)throw Error('Module did not register: '+path);return item.exports;}
root.__requireRecoveredModule__=recoveredRequire;
root.__runRecoveredModule__=(name,factory)=>{name=norm(name);if(modules.has(name))return modules.get(name).exports;const item={exports:{}};modules.set(name,item);factory.call(root,recoveredRequire,item,item.exports,root.__runRecoveredModule__,Promise,setTimeout.bind(root),clearTimeout.bind(root),setInterval.bind(root),clearInterval.bind(root),requestAnimationFrame.bind(root),cancelAnimationFrame.bind(root),root,undefined,undefined,undefined,undefined);return item.exports;};
require('./platform.js');
const gateway=new Proxy(TTMinis.game,{get(target,name){const direct={login:options=>TTMinis.game.login(options),createRewardedVideoAd:options=>TTMinis.game.createRewardedVideoAd(options),createInterstitialAd:options=>TTMinis.game.createInterstitialAd(options),addShortcut:options=>TTMinis.game.addShortcut(options),getShortcutMissionReward:options=>TTMinis.game.getShortcutMissionReward(options),startEntranceMission:options=>TTMinis.game.startEntranceMission(options),getEntranceMissionReward:options=>TTMinis.game.getEntranceMissionReward(options)};if(direct[name])return typeof target[name]==='function'?direct[name]:undefined;const value=target[name]===undefined?nativeHost[name]:target[name];const owner=target[name]===undefined?nativeHost:target;return typeof value==='function'?value.bind(owner):value;}});
root.__blockTikTok=BlockMazeTikTok.createPlatform(config,gateway);
function load(name){return new Promise((resolve,reject)=>{const owner=typeof TTMinis.game.loadSubpackage==='function'?TTMinis.game:nativeHost;owner.loadSubpackage({name,success:resolve,fail:()=>reject(Error('Unable to load '+name))});});}
(async()=>{
 await load('engine');await load('localization-art');
 recoveredRequire('microgame-adapter.js');
 const listeners=new Map();root.addEventListener=(name,fn)=>{if(!listeners.has(name))listeners.set(name,new Set());listeners.get(name).add(fn);};root.removeEventListener=(name,fn)=>listeners.get(name)?.delete(fn);root.dispatchEvent=event=>{for(const fn of listeners.get(event.type)||[])fn(event);};if(!root.Event)root.Event=class{constructor(type){this.type=type;}};
 require('./countries.js');require('./localization.js');require('./localization-assets.js');
 for(const name of ['libs/laya.core-1ee2e.js','libs/laya.d3-3b9df.js','libs/laya.webgl_2D-1cb0b.js','libs/laya.webgl_3D-13676.js','libs/laya.ui2-fe4b7.js','libs/spine-core-4.2-55f4a.js','libs/laya.spine-6441a.js','libs/laya.adapter-bytedance-1a715.js']){
  recoveredRequire(name);if(name.startsWith('libs/laya.core-'))root.__sandI18n.install();if(name.startsWith('libs/laya.ui2-'))root.__sandAssetI18n.install();
 }
 Laya.URL.basePaths=Laya.URL.basePaths||{};for(const name of Object.keys(paths).filter(x=>x.startsWith('packages/')&&x.endsWith('/game.js'))){const base=name.slice(0,-7);Laya.URL.basePaths[base]='subpackages/'+base;}
 // Remote game data is shipped as assets on the configured developer CDN, never executable code.
 if(config.assetBase){const base=config.assetBase.replace(/\/+$/,'')+'/';Laya.URL.basePaths['packages/levels/']=base+'packages/levels/';}
 require('./leaderboard-native.js');require('./save-native.js');await window.__blockSave.install();recoveredRequire('js/bundle-4b507.js');recoveredRequire('js/index-34e6c.js');root.__sandBootLoaded=true;
})().catch(error=>{console.error('[Block Maze native startup]',error.message);if(typeof nativeHost.showModal==='function')nativeHost.showModal({title:'Connection problem',content:'We could not connect. Please close the game and try again.',showCancel:false});});
