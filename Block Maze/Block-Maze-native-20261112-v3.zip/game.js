/* Block Maze TikTok native candidate. No HTML entry, dynamic remote JS, or original developer login. */
'use strict';
const root=globalThis,config=require('./config.js'),packageNames=require('./package-names.js');
function bootStage(value){root.__blockMazeBootStage=value;console.info('[Block Maze boot]',value);}
bootStage('entry');
if(!root.TTMinis||!TTMinis.game)throw Error('Open this package in the TikTok Mini Games runtime');
root.GameGlobal=root;root.window=root;const nativeHost=(root.tt&&typeof root.tt.createCanvas==='function')?root.tt:(root.wx&&typeof root.wx.createCanvas==='function')?root.wx:TTMinis.game;root.tt=nativeHost;
const runtimePerformance=root.performance&&typeof root.performance.now==='function'?root.performance:null;
const clockStart=Date.now();let clockLast=0;
function millisecondClock(){clockLast=Math.max(clockLast,Date.now()-clockStart);return clockLast;}
const nativeFrame=typeof root.requestAnimationFrame==='function'?root.requestAnimationFrame.bind(root):typeof nativeHost.requestAnimationFrame==='function'?nativeHost.requestAnimationFrame.bind(nativeHost):null;
const nativeCancelFrame=typeof root.cancelAnimationFrame==='function'?root.cancelAnimationFrame.bind(root):typeof nativeHost.cancelAnimationFrame==='function'?nativeHost.cancelAnimationFrame.bind(nativeHost):null;
function frame(callback){if(nativeFrame)return nativeFrame(callback);if(root.canvas&&typeof root.canvas.requestAnimationFrame==='function')return root.canvas.requestAnimationFrame(callback);return setTimeout(()=>callback(Date.now()),16);}
function cancelFrame(id){if(nativeCancelFrame)return nativeCancelFrame(id);if(root.canvas&&typeof root.canvas.cancelAnimationFrame==='function')return root.canvas.cancelAnimationFrame(id);return clearTimeout(id);}
const paths=require('./module-map.js'),modules=new Map();
function norm(path){return String(path).replace(/^\.\//,'');}
function recoveredRequire(path){path=norm(path);if(!modules.has(path)){const physical=paths[path];if(!physical)throw Error('Unbundled executable: '+path);require('./'+physical);}const item=modules.get(path);if(!item)throw Error('Module did not register: '+path);return item.exports;}
root.__requireRecoveredModule__=recoveredRequire;
root.__runRecoveredModule__=(name,factory)=>{name=norm(name);if(modules.has(name))return modules.get(name).exports;const item={exports:{}};modules.set(name,item);factory.call(root,recoveredRequire,item,item.exports,root.__runRecoveredModule__,Promise,setTimeout.bind(root),clearTimeout.bind(root),setInterval.bind(root),clearInterval.bind(root),frame,cancelFrame,root,undefined,undefined,undefined,undefined);return item.exports;};
require('./platform.js');
const gateway=new Proxy(TTMinis.game,{get(target,name){const direct={login:options=>TTMinis.game.login(options),createRewardedVideoAd:options=>TTMinis.game.createRewardedVideoAd(options),createInterstitialAd:options=>TTMinis.game.createInterstitialAd(options),addShortcut:options=>TTMinis.game.addShortcut(options),getShortcutMissionReward:options=>TTMinis.game.getShortcutMissionReward(options),startEntranceMission:options=>TTMinis.game.startEntranceMission(options),getEntranceMissionReward:options=>TTMinis.game.getEntranceMissionReward(options)};if(direct[name])return typeof target[name]==='function'?direct[name]:undefined;const value=target[name]===undefined?nativeHost[name]:target[name];const owner=target[name]===undefined?nativeHost:target;return typeof value==='function'?value.bind(owner):value;}});
root.__blockTikTok=BlockMazeTikTok.createPlatform(config,gateway);
function load(name){bootStage('subpackage:'+name);return new Promise((resolve,reject)=>{let done=false;const timer=setTimeout(()=>finish(Error('Subpackage timed out: '+name)),45000);function finish(error,value){if(done)return;done=true;clearTimeout(timer);error?reject(error):resolve(value);}try{const owner=typeof TTMinis.game.loadSubpackage==='function'?TTMinis.game:nativeHost;if(typeof owner.loadSubpackage!=='function')throw Error('loadSubpackage unavailable');owner.loadSubpackage({name,success:value=>finish(null,value),fail:error=>finish(Error('Subpackage failed: '+name+' '+String(error&&error.errMsg||''))),complete(){}});}catch(error){finish(error);}});}
(async()=>{
 await load('engine');await load('localization-art');
 bootStage('adapter');recoveredRequire('microgame-adapter.js');
 // The recovered Douyin adapter divides getPerformance().now() by 1000.
 // Keep the runtime's standard millisecond clock, or a monotonic millisecond fallback.
 root.performance=runtimePerformance||{now:millisecondClock};
 const listeners=new Map();root.addEventListener=(name,fn)=>{if(!listeners.has(name))listeners.set(name,new Set());listeners.get(name).add(fn);};root.removeEventListener=(name,fn)=>listeners.get(name)?.delete(fn);root.dispatchEvent=event=>{for(const fn of listeners.get(event.type)||[])fn(event);};if(!root.Event)root.Event=class{constructor(type){this.type=type;}};
 require('./countries.js');require('./localization.js');require('./localization-assets.js');
 for(const name of ['libs/laya.core-1ee2e.js','libs/laya.d3-3b9df.js','libs/laya.webgl_2D-1cb0b.js','libs/laya.webgl_3D-13676.js','libs/laya.ui2-fe4b7.js','libs/spine-core-4.2-55f4a.js','libs/laya.spine-6441a.js','libs/laya.adapter-bytedance-1a715.js']){
  bootStage(name);recoveredRequire(name);if(name.startsWith('libs/laya.core-'))root.__sandI18n.install();if(name.startsWith('libs/laya.ui2-'))root.__sandAssetI18n.install();
 }
 // Laya basePaths prepends its value and retains the full logical package path.
 Laya.URL.basePaths=Laya.URL.basePaths||{};for(const name of Object.keys(paths).filter(x=>x.startsWith('packages/')&&x.endsWith('/game.js'))){const base=name.slice(0,-7);Laya.URL.basePaths[base]='subpackages/';}
 // Remote game data is shipped as assets on the configured developer CDN, never executable code.
 if(config.assetBase){const base=config.assetBase.replace(/\/+$/,'')+'/';Laya.URL.basePaths['packages/levels/']=base;}
 Laya.addBeforeInitCallback(()=>{
  const downloader=Laya.Loader.downloader,original=downloader.package;
  if(downloader.__blockMazeRemoteData)return;
  downloader.__blockMazeRemoteData=true;
  downloader.package=function(name,progress,complete){
   // levels contains JSON data on HTTPS, not executable code or a local subpackage.
   if(String(name).replace(/\/+$/,'')==='packages/levels'){complete({loadScript:false});return;}
   const canonical=packageNames[name];if(!canonical){complete({loadScript:false},'Unknown native package: '+name);return;}
   console.info("[Native package]",name,"=>",canonical);return original.call(this,canonical,progress,complete);
  };
 });
 require('./leaderboard-native.js');require('./save-native.js');bootStage('account-and-cloud-save');await window.__blockSave.install();bootStage('business-bundle');recoveredRequire('js/bundle-4b507.js');bootStage('engine-start');recoveredRequire('js/index-34e6c.js');root.__sandBootLoaded=true;
})().catch(error=>{console.error('[Block Maze native startup]',root.__blockMazeBootStage,error.stack||error.message);const content='Startup stopped at '+root.__blockMazeBootStage+'. Please reopen the game.';if(typeof nativeHost.showModal==='function')nativeHost.showModal({title:'Unable to start',content,showCancel:false});else if(typeof nativeHost.showToast==='function')nativeHost.showToast({title:content,icon:'none',duration:10000});});
